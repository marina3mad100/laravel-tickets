<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
use Spatie\Permission\Traits\HasRoles;
use Illuminate\Support\Facades\Hash;


class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
	use HasRoles;
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name');
            $table->string('email')->unique();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password');
			$table->boolean('super_admin')->default(0);
			$table->boolean('admin')->default(0);
            $table->rememberToken();
            $table->timestamps();
        });
		
		
        DB::table('users')->insert([
            ['name' => 'super administrator', 'email' => 'superadministrator@gmail.com','password'=>Hash::make('123456'),'super_admin'=>1]
        ]);		
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
