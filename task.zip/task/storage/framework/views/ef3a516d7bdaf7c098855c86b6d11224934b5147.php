<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
	<script src="<?php echo e(asset('js/app.js')); ?>" ></script>
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
	
    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light navbar-laravel">
            <div class="container">
				<?php if(Auth::user()): ?>
					<?php if(Auth::user()->is_owner()): ?>
						<a class="navbar-brand" href="<?php echo e(url('/')); ?>"><?php echo app('translator')->getFromJson('messages.TicketsSys'); ?></a>
					<?php else: ?>
						<a class="navbar-brand" href="<?php echo e(route('tickets.dashboard' ,[ app()->getLocale(), Auth::user()->id])); ?>"><?php echo app('translator')->getFromJson('messages.DashboardTickets'); ?></a>
					
					<?php endif; ?>
				<?php endif; ?>	
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
					<?php if(Auth::user()): ?>




					<?php if(Auth::user()->get_permission_for_this_page_link('roles.index') || Auth::user()->get_permission_for_this_page_link('roles.create') || Auth::user()->get_permission_for_this_page_link('roles.edit') || Auth::user()->get_permission_for_this_page_link('roles.destroy') ||  Auth::user()->super_admin == 1): ?>  
						<ul class="navbar-nav mr-auto">
							<li class="nav-item dropdown">
								<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
									<?php echo app('translator')->getFromJson('messages.Roles'); ?>
								</a>
								<div class="dropdown-menu" aria-labelledby="navbarDropdown">
									<?php if(Auth::user()->get_permission_for_this_page_link('roles.create') || Auth::user()->super_admin == 1): ?>
										<a class="dropdown-item" href="<?php echo e(route('roles.create',app()->getLocale())); ?>"><?php echo app('translator')->getFromJson('messages.CreateRole'); ?></a>
									<?php endif; ?>
									<?php if(Auth::user()->get_permission_for_this_page_link('roles.index') || Auth::user()->get_permission_for_this_page_link('roles.edit') || Auth::user()->get_permission_for_this_page_link('roles.destroy') || Auth::user()->get_permission_for_this_page_link('roles.create') ||  Auth::user()->super_admin == 1): ?>
										<a class="dropdown-item" href="<?php echo e(route('roles.index',app()->getLocale())); ?>"><?php echo app('translator')->getFromJson('messages.AllRoles'); ?></a>
									<?php endif; ?>
						
								</div>
							</li>
						
						</ul>
					<?php endif; ?>	
					<?php if(Auth::user()->get_permission_for_this_page_link('permissions.index') || Auth::user()->get_permission_for_this_page_link('permissions.create') || Auth::user()->get_permission_for_this_page_link('permissions.edit') || Auth::user()->get_permission_for_this_page_link('permissions.destroy') || Auth::user()->super_admin == 1): ?>  
						<ul class="navbar-nav mr-auto">
							<li class="nav-item dropdown">
								<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
								<?php echo app('translator')->getFromJson('messages.Permissions'); ?>
								</a>
								<div class="dropdown-menu" aria-labelledby="navbarDropdown">
									<?php if(Auth::user()->get_permission_for_this_page_link('permissions.create') || Auth::user()->super_admin == 1): ?>
										<a class="dropdown-item" href="<?php echo e(route('permissions.create',app()->getLocale())); ?>"><?php echo app('translator')->getFromJson('messages.CreatePermission'); ?></a>	
									<?php endif; ?>
									<?php if(Auth::user()->get_permission_for_this_page_link('permissions.index') || Auth::user()->get_permission_for_this_page_link('permissions.edit') || Auth::user()->get_permission_for_this_page_link('permissions.destroy') || Auth::user()->get_permission_for_this_page_link('permissions.create') || Auth::user()->super_admin == 1): ?>
										<a class="dropdown-item" href="<?php echo e(route('permissions.index',app()->getLocale())); ?>"><?php echo app('translator')->getFromJson('messages.AllPermissions'); ?></a>																	
									<?php endif; ?>
					
							  </div>
							</li>
							
						  </ul>
					<?php endif; ?>
					<?php if(Auth::user()->get_permission_for_this_page_link('admins.index') || Auth::user()->get_permission_for_this_page_link('admins.create') || Auth::user()->get_permission_for_this_page_link('admins.edit') || Auth::user()->get_permission_for_this_page_link('admins.destroy') ||  Auth::user()->super_admin == 1): ?>  
						<ul class="navbar-nav mr-auto">
							<li class="nav-item dropdown">
								<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
									<?php echo app('translator')->getFromJson('messages.Admins'); ?>
								</a>
								<div class="dropdown-menu" aria-labelledby="navbarDropdown">
									<?php if(Auth::user()->get_permission_for_this_page_link('admins.create') || Auth::user()->super_admin == 1): ?>
										<a class="dropdown-item" href="<?php echo e(route('admins.create',app()->getLocale())); ?>"><?php echo app('translator')->getFromJson('messages.CreateAdmin'); ?></a>	
									<?php endif; ?>
									<?php if(Auth::user()->get_permission_for_this_page_link('admins.index') || Auth::user()->get_permission_for_this_page_link('admins.edit') || Auth::user()->get_permission_for_this_page_link('admins.destroy') || Auth::user()->super_admin == 1): ?>
										<a class="dropdown-item" href="<?php echo e(route('admins.index',app()->getLocale())); ?>"><?php echo app('translator')->getFromJson('messages.AllAdmins'); ?></a>																	
									<?php endif; ?>
					
							  </div>									

							</li>
						
						</ul>	
					<?php endif; ?> 
					<?php if(Auth::user()->get_permission_for_this_page_link('functions.show')  || Auth::user()->super_admin == 1): ?>  						
						<ul class="navbar-nav mr-auto">
							<li class="nav-item dropdown">
								<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
									<?php echo app('translator')->getFromJson('messages.SiteFunction'); ?>
								</a>
								<div class="dropdown-menu" aria-labelledby="navbarDropdown">
									<?php if(Auth::user()->get_permission_for_this_page_link('functions.show') || Auth::user()->super_admin == 1): ?>
										<a class="dropdown-item" href="<?php echo e(route('functions.show' ,app()->getLocale())); ?>"><?php echo app('translator')->getFromJson('messages.SiteFunPermission'); ?></a>
									<?php endif; ?>
								</div>
							</li>
						
					   </ul>	
					<?php endif; ?> 
					<?php if(Auth::user()->get_permission_for_this_page_link('tickets.create') || Auth::user()->get_permission_for_this_page_link('tickets.index') || Auth::user()->get_permission_for_this_page_link('tickets.edit') || Auth::user()->get_permission_for_this_page_link('tickets.destroy')  || Auth::user()->super_admin == 1 || Auth::user()->is_owner() == 1): ?>  						

						<ul class="navbar-nav mr-auto">
							<li class="nav-item dropdown">
								<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
									<?php echo app('translator')->getFromJson('messages.Tickets'); ?>
								</a>
								<div class="dropdown-menu" aria-labelledby="navbarDropdown">
									<?php if(Auth::user()->get_permission_for_this_page_link('tickets.create') || Auth::user()->super_admin == 1 ): ?>
										<a class="dropdown-item" href="<?php echo e(route('tickets.create',app()->getLocale())); ?>"><?php echo app('translator')->getFromJson('messages.CreateTickets'); ?></a>	
										<a class="dropdown-item" href="<?php echo e(route('tickets.mytickets' ,[app()->getLocale(),Auth::user()->id])); ?>"><?php echo app('translator')->getFromJson('messages.MyTickets'); ?></a>
									
									<?php endif; ?>
									<?php if(Auth::user()->get_permission_for_this_page_link('tickets.index') || Auth::user()->super_admin == 1): ?>
										<a class="dropdown-item" href="<?php echo e(route('tickets.index',app()->getLocale())); ?>"><?php echo app('translator')->getFromJson('messages.AllTickets'); ?></a>																	
									<?php endif; ?>

									<?php if(Auth::user()->is_owner()): ?>
										<a class="dropdown-item" href="<?php echo e(route('tickets.addticket',app()->getLocale())); ?>"><?php echo app('translator')->getFromJson('messages.CreateTickets'); ?></a>	
										<a class="dropdown-item" href="<?php echo e(route('tickets.ownertickets' ,[ app()->getLocale(),Auth::user()->id])); ?>"><?php echo app('translator')->getFromJson('messages.MyTickets'); ?></a>
																				
									<?php endif; ?>

								
									
					
							  </div>									

							</li>
						
						</ul>	
					<?php endif; ?>
                <?php endif; ?>	                
		
					<select class="form-group" onchange="return chk_lang()" id="lang">
						<option value="en" <?php if(App::getLocale()=='en'): ?> <?php echo e('selected'); ?> <?php endif; ?>>English</option>
						<option value="ar" <?php if(App::getLocale()=='ar'): ?> <?php echo e('selected'); ?> <?php endif; ?>>Arabic</option>
						
					</select>			
                  <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('login',app()->getLocale())); ?>"><?php echo e(__('messages.Login')); ?></a>
                            </li>
                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register',app()->getLocale())); ?>"><?php echo e(__('messages.Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout',app()->getLocale())); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('messages.Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout',app()->getLocale())); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>

	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap-datepicker.css')); ?>" />
	<script src="<?php echo e(asset('js/bootstrap-datepicker.js')); ?>" ></script>
	<script>
		// initialize input widgets first


		$('.date , .date2').datepicker({
			'format': 'yyyy-mm-dd',
			'autoclose': true
		});

	</script>
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.css">
  
	<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.js"></script>
		<script>
			$(document).ready( function () {
				$('#example,#example2,#example3').DataTable();
			} );
	</script>
	<script>
		function chk_lang(){
		    var lang = document.getElementById('lang').value.trim();
				$.ajax({
                    url: "/changelangouage",
					type: "get", // call the function in index controler 
					data: {
						lang:lang,
					},
					success: function(result)
					{
						var arr = [ "ar", "en" ];
						var href = window.location.href;

						if(href.search("/ar/") > -1 ){
							var res = href.replace("/ar/", '/'+lang+'/');
						}
						else if(href.search("/en/") > -1){
							var res = href.replace("/en/", '/'+lang+'/');
							
						}
						window.location.href=res;
						return true;
					}
				   });			
			
		}
	</script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\task\resources\views/layouts/app.blade.php ENDPATH**/ ?>