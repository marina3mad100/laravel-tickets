<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo app('translator')->getFromJson('messages.Roles'); ?></div>

                <div class="card-body">
					<?php echo $__env->make('partials._messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 
                    <?php if($roles->count()>0): ?>                                                                          
                        <table id="example" class="table table-striped">
							<thead>
							  <tr>
								<th scope="col"> <?php echo app('translator')->getFromJson('messages.RoleTitle'); ?> </th>
								<th scope="col"> <?php echo app('translator')->getFromJson('messages.Permissions'); ?> </th>
								<?php if(Auth::user()->get_permission_for_this_page_link('roles.edit') || Auth::user()->super_admin == 1): ?>
									<th scope="col"><?php echo app('translator')->getFromJson('messages.edit'); ?></th>
								<?php endif; ?>
								<?php if(Auth::user()->get_permission_for_this_page_link('roles.destroy') || Auth::user()->super_admin == 1): ?>
									<th scope="col"><?php echo app('translator')->getFromJson('messages.delete'); ?></th>
								<?php endif; ?>								
							  </tr>
							</thead>
							<tbody>
								<?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td> <?php echo e($role->name); ?></td>
										<td>
											<?php if($role->permissions->count() > 0): ?>
												<?php $__currentLoopData = $role->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<span class="badge"><?php echo e($permission->name); ?></span>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											
											<?php endif; ?>
										</td>										
										<?php if(Auth::user()->get_permission_for_this_page_link('roles.edit') || Auth::user()->super_admin == 1): ?>	
											<td>
												<?php if($role->name != 'Super Admin'): ?>
													<a class="btn btn-primary" href="<?php echo e(route('roles.edit',[app()->getLocale() , $role->id ])); ?>"> <?php echo app('translator')->getFromJson('messages.edit'); ?></a> 													
												<?php endif; ?>
											</td>
										<?php endif; ?>	
										<?php if(Auth::user()->get_permission_for_this_page_link('roles.destroy') || Auth::user()->super_admin == 1): ?>
											<td> 
												<?php if($role->name != 'Super Admin'): ?>
													<form action="<?php echo e(route('roles.destroy' , [app()->getLocale() , $role->id ])); ?>" method="POST"  >
													<?php echo e(csrf_field()); ?>

													<?php echo e(method_field('DELETE')); ?>

													<button type="submit" class="btn btn-danger"><?php echo app('translator')->getFromJson('messages.delete'); ?></button>
													</form>
												<?php endif; ?>
										   </td>
										<?php endif; ?>   
									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>								
							</tbody>
						</table>
					<?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\task\resources\views/roles/index.blade.php ENDPATH**/ ?>