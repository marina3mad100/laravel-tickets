<?php $__env->startSection('content'); ?>






<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo app('translator')->getFromJson('messages.CreateRole'); ?></div>

                <div class="card-body">

					<?php echo $__env->make('partials._messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    

                    <form action="<?php echo e(route('roles.store',app()->getLocale())); ?>" method="POST"  >
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                          <label for="name"><?php echo app('translator')->getFromJson('messages.RoleName'); ?></label>
                          <input type="text" class="form-control" name="role" value="<?php if($errors->any()): ?> <?php echo e(old('role')); ?> <?php elseif(Session::has('success')): ?> <?php echo e(''); ?>  <?php endif; ?>"  placeholder="<?php echo app('translator')->getFromJson('messages.Enter'); ?> <?php echo app('translator')->getFromJson('messages.RoleName'); ?>">
                         </div>
                        
                         
                         
                        <button type="submit" class="btn btn-primary"><?php echo app('translator')->getFromJson('messages.save'); ?></button>
                      </form>      
                    







                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\task\resources\views/roles/create.blade.php ENDPATH**/ ?>