<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><?php echo app('translator')->getFromJson('messages.AllTickets'); ?></div>

                <div class="card-body"> 
				    <?php echo $__env->make('partials._messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>                
                    <?php if($tickets->count()>0): ?>
                                    
                        <table id="example" class="table table-striped">
                                <thead>
                                  <tr>
									<th scope="col"><?php echo app('translator')->getFromJson('messages.TicketNo'); ?> </th>
									<th scope="col"><?php echo app('translator')->getFromJson('messages.owner'); ?></th>
									<th scope="col"><?php echo app('translator')->getFromJson('messages.fromdate'); ?></th>
									<th scope="col"><?php echo app('translator')->getFromJson('messages.todate'); ?></th>
									<th scope="col"><?php echo app('translator')->getFromJson('messages.assignedadmin'); ?></th>
									<th scope="col"><?php echo app('translator')->getFromJson('messages.description'); ?></th>										
									<th scope="col"><?php echo app('translator')->getFromJson('messages.status'); ?></th>
									<?php if(Auth::user()->get_permission_for_this_page_link('tickets.edit') || Auth::user()->super_admin == 1): ?>
										<th scope="col"><?php echo app('translator')->getFromJson('messages.edit'); ?></th>
									<?php endif; ?>
									<?php if(Auth::user()->get_permission_for_this_page_link('tickets.destroy') || Auth::user()->super_admin == 1): ?>
										<th scope="col"><?php echo app('translator')->getFromJson('messages.delete'); ?></th>
									<?php endif; ?>	
									<th>Action</th>
                                  </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<tr>
											<td> <?php echo e($ticket->ticket_no); ?> </td>
											<td> <?php echo e($ticket->user->name); ?> </td>
											<td> <?php echo e($ticket->start_date); ?> </td>
											<td> <?php echo e($ticket->end_date); ?> </td>
											<td> 
												<?php if(isset($ticket->assigned_admin->name)): ?>
													<?php echo e($ticket->assigned_admin->name); ?>

												<?php endif; ?>
											</td>
											<td> <?php echo e($ticket->description); ?> </td>											
											<td>
												<?php if($ticket->status == 0): ?>
													<span class="badge"><?php echo app('translator')->getFromJson('messages.Closed'); ?></span>
												<?php elseif($ticket->status == 1): ?>
													<span class="badge" style="background:green;"><?php echo app('translator')->getFromJson('messages.Opened'); ?></span>	
												<?php elseif($ticket->status == 2): ?>
													<span class="badge" style="background:orange;"><?php echo app('translator')->getFromJson('messages.ReOpened'); ?></span>														
												<?php endif; ?>
											</td>
											
										
											<?php if(Auth::user()->get_permission_for_this_page_link('tickets.edit') || Auth::user()->super_admin == 1): ?>	
												<td> <a class="btn btn-primary" href="<?php echo e(route('tickets.edit',[app()->getLocale() ,$ticket->id ])); ?>"><?php echo app('translator')->getFromJson('messages.edit'); ?></a></td>
											<?php endif; ?>
											<?php if(Auth::user()->get_permission_for_this_page_link('tickets.destroy') || Auth::user()->super_admin == 1): ?>
												<td> 
													<form action="<?php echo e(route('tickets.destroy' , [app()->getLocale() , $ticket->id ])); ?>" method="POST"  >
													<?php echo e(csrf_field()); ?>

													<?php echo e(method_field('DELETE')); ?>

													<button type="submit" class="btn btn-danger"><?php echo app('translator')->getFromJson('messages.delete'); ?></button>
													</form>
												</td>
											<?php endif; ?>

											<td>
												<?php if($ticket->status == 0 &&  strtotime(date('Y-m-d')) > strtotime($ticket->end_date) ): ?>
													<?php if(Auth::user()->get_permission_for_this_page_link('tickets.reopen')): ?>
													<a class="btn btn-warning" data-toggle="modal" data-target="#modal<?php echo e($ticket->id); ?>" href="<?php echo e(route('tickets.reopen',[app()->getLocale() , $ticket->id ])); ?>"><?php echo app('translator')->getFromJson('messages.reopen'); ?></a>
													<div id="modal<?php echo e($ticket->id); ?>" class="modal fade" role="dialog">
													  <div class="modal-dialog">

														<!-- Modal content-->
														<div class="modal-content">
														    <form action="<?php echo e(route('tickets.reopen',[app()->getLocale() , $ticket->id])); ?>" method="POST"  >
															<?php echo e(csrf_field()); ?>

																<div class="modal-header">
																	<button type="button" class="close" data-dismiss="modal">&times;</button>
																</div>
																<div class="modal-body">

																<div class="form-group">
																	<input type="hidden" class="form-control date" name="today_date" value="<?php echo e(date('Y-m-d')); ?>" placeholder="Enter To Date" readonly >
																	<label for="name"><?php echo app('translator')->getFromJson('messages.ReopenToDate'); ?></label>
																	<input type="text" class="form-control date" name="reopen_end_date" value="<?php if($errors->any()): ?> <?php echo e(old('end_date')); ?>    <?php endif; ?>" placeholder="<?php echo app('translator')->getFromJson('messages.Enter'); ?> <?php echo app('translator')->getFromJson('messages.todate'); ?>" readonly >
																</div>	
																</div>
																<div class="modal-footer">
																	<button type="submit" class="btn btn-primary"><?php echo app('translator')->getFromJson('messages.save'); ?></button>
																	<button type="button" class="btn btn-default" data-dismiss="modal"><?php echo app('translator')->getFromJson('messages.close'); ?></button>
																</div>
															</form>
														</div>

													  </div>
													</div>												
												
													<?php endif; ?>
												<?php elseif($ticket->status == 0 &&  strtotime($ticket->end_date) >  strtotime(date('Y-m-d')) ): ?>
													<?php if(Auth::user()->get_permission_for_this_page_link('tickets.open')): ?>
													<a class="btn btn-success" href="<?php echo e(route('tickets.open',[app()->getLocale() , $ticket->id ])); ?>"><?php echo app('translator')->getFromJson('messages.open'); ?></a>
													<?php endif; ?>
												<?php elseif($ticket->status == 1 || $ticket->status == 2): ?>
													<?php if(Auth::user()->get_permission_for_this_page_link('tickets.close')): ?>
													<a class="btn btn-danger" href="<?php echo e(route('tickets.close',[app()->getLocale() , $ticket->id ])); ?>"><?php echo app('translator')->getFromJson('messages.close'); ?></a>
													<?php endif; ?>
													
												<?php endif; ?>										
											</td>

											
										</tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </tbody>
                        </table>
					<?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\task\resources\views/tickets/index.blade.php ENDPATH**/ ?>