<?php $__env->startSection('content'); ?>






<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo app('translator')->getFromJson('messages.ِِAllAdmins'); ?></div>

                <div class="card-body">
 
					<?php echo $__env->make('partials._messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
                    <?php if($admins->count()>0): ?>                                   
                        <table id="example" class="table table-striped">
							<thead>
								<tr>
									<th scope="col"> <?php echo app('translator')->getFromJson('messages.Name'); ?> </th>
									<th scope="col"><?php echo app('translator')->getFromJson('messages.E-Mail Address'); ?></th>
									<th scope="col"><?php echo app('translator')->getFromJson('messages.Roles'); ?></th>
									<th scope="col"><?php echo app('translator')->getFromJson('messages.Permissions'); ?></th>
									<?php if(Auth::user()->get_permission_for_this_page_link('admins.edit') || Auth::user()->super_admin == 1): ?>
										<th scope="col"><?php echo app('translator')->getFromJson('messages.edit'); ?></th>
									<?php endif; ?>
									<?php if(Auth::user()->get_permission_for_this_page_link('admins.destroy') || Auth::user()->super_admin == 1): ?>
										<th scope="col"><?php echo app('translator')->getFromJson('messages.delete'); ?></th>
									<?php endif; ?>								
							  </tr>
							</thead>
							<tbody>
								<?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($admin->name); ?> </td>
									<td><?php echo e($admin->email); ?> </td>
									<td>
										<?php if($admin->getRoleNames()->count() > 0): ?>
											<?php $__currentLoopData = $admin->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<span class="badge"  data-toggle="modal" data-target="#<?php echo e($role); ?>"><?php echo e($role); ?></span>																																			
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										
										<?php endif; ?>										

									</td>
									<td>
										<?php if($admin->getAllPermissions()->count() > 0): ?>
											<?php $__currentLoopData = $admin->getAllPermissions(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<span class="badge"><?php echo e($permission->name); ?></span>											
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>										
										<?php endif; ?>										
									</td>										
									<?php if(Auth::user()->get_permission_for_this_page_link('admins.edit') || Auth::user()->super_admin == 1): ?>
										<td> <a class="btn btn-primary" href="<?php echo e(route('admins.edit',[app()->getLocale() , $admin->id ])); ?>"> <?php echo app('translator')->getFromJson('messages.edit'); ?></a> </td>
									<?php endif; ?>
									<?php if(Auth::user()->get_permission_for_this_page_link('admins.destroy') || Auth::user()->super_admin == 1): ?>	
										<td> 
											<form action="<?php echo e(route('admins.destroy' , [app()->getLocale() ,  $admin->id ])); ?>" method="POST"  >
											<?php echo e(csrf_field()); ?>

											<?php echo e(method_field('DELETE')); ?>

											<button type="submit" class="btn btn-danger"><?php echo app('translator')->getFromJson('messages.delete'); ?></button>
											</form>
									   </td> 
									<?php endif; ?>   
									  </tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>								
							</tbody>
						</table>     
					<?php endif; ?>	
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\task\resources\views/users/index.blade.php ENDPATH**/ ?>