<?php $__env->startSection('content'); ?>






<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo app('translator')->getFromJson('messages.EditPermission'); ?></div>

                <div class="card-body">

					<?php echo $__env->make('partials._messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    

					<form action="<?php echo e(route('permissions.update' , [app()->getLocale() ,  $permission->id ])); ?>" method="POST"  >
                        <?php echo e(csrf_field()); ?>

						<?php echo e(method_field('PUT')); ?>

                        <div class="form-group">
                          <label for="name"><?php echo app('translator')->getFromJson('messages.PermissionName'); ?></label>
                          <input type="text" class="form-control" name="permission" value="<?php if($errors->any()): ?> <?php echo e(old('permission')); ?> <?php else: ?> <?php echo e($permission->name); ?>  <?php endif; ?>"  placeholder="<?php echo app('translator')->getFromJson('messages.Enter'); ?> <?php echo app('translator')->getFromJson('messages.PermissionName'); ?>">
                         </div>
                        
                        <div class="form-group">
                            <label for="role"><?php echo app('translator')->getFromJson('messages.Roles'); ?></label>

							<div class="form-check">
								<?php if($roles->count()>0): ?>
									<?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>								
									<input class="form-check-input" type="checkbox" name="role[]" value="<?php echo e($role->id); ?>" 
									<?php if($permission->roles->count() > 0): ?> 
										<?php $__currentLoopData = $permission->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p_role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php if($p_role->id == $role->id): ?>
												checked
											<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												
									<?php endif; ?>  />
									<label class="form-check-label"  >
											<?php echo e($role->name); ?>

										  </label><br>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
								
							  </div>							
							
					
                         </div>                         
                         
                        <button type="submit" class="btn btn-primary"><?php echo app('translator')->getFromJson('messages.save'); ?></button>
                      </form>      
                    







                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\task\resources\views/permissions/edit.blade.php ENDPATH**/ ?>