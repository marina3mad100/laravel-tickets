<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo app('translator')->getFromJson('messages.Register'); ?></div>
				<?php echo $__env->make('partials._messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('admins.store',app()->getLocale())); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo app('translator')->getFromJson('messages.Name'); ?></label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>"  autofocus>

                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo app('translator')->getFromJson('messages.E-Mail Address'); ?></label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" >

                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo app('translator')->getFromJson('messages.Password'); ?> </label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" >

                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo app('translator')->getFromJson('messages.Confirm Password'); ?></label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" >
                            </div>
                        </div>
						
						<div class="form-group row">
							<label for="role" class="col-md-4 col-form-label text-md-right"><?php echo app('translator')->getFromJson('messages.Roles'); ?> </label>

							<div class="form-check">
								<?php if($roles->count()>0): ?>
									<?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
										<?php if(($role->name == 'Super Admin' && Auth::user()->super_admin == 1) || $role->name != 'Super Admin'): ?>
											<input class="form-check-input" type="checkbox" id="role<?php echo e($role->id); ?>" name="role[]" value="<?php echo e($role->id); ?>" onchange=" return validate(<?php echo e($role->id); ?>)" >
											<label class="form-check-label"  >
												<?php echo e($role->name); ?>

											</label><br>											
										<?php endif; ?>

									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
								
							</div>								
						</div>


						<div class="form-group row">
							<label for="permission" class="col-md-4 col-form-label text-md-right"><?php echo app('translator')->getFromJson('messages.Permissions'); ?> </label>

							<div class="form-check">
								<?php if($permisions->count()>0): ?>
									<?php $__currentLoopData = $permisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>								
									<input class="form-check-input" type="checkbox" id="role<?php echo e($permission->id); ?>" name="permission[]" value="<?php echo e($permission->id); ?>"  >
									<label class="form-check-label"  >
											<?php echo e($permission->name); ?>

										  </label><br>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
								
							</div>								
						</div>

					
                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo app('translator')->getFromJson('messages.save'); ?> 
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\task\resources\views/users/create.blade.php ENDPATH**/ ?>