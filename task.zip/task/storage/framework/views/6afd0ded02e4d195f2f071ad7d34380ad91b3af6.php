<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><?php echo app('translator')->getFromJson('messages.AssignedTicket'); ?></div>

                <div class="card-body"> 
				    <?php echo $__env->make('partials._messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>                
                    <?php if($tickets->count()>0): ?>
                                    
                        <table id="example" class="table table-striped">
                                <thead>
                                  <tr>
									<th scope="col"><?php echo app('translator')->getFromJson('messages.TicketNo'); ?> </th>
									<th scope="col"><?php echo app('translator')->getFromJson('messages.owner'); ?></th>
									<th scope="col"><?php echo app('translator')->getFromJson('messages.fromdate'); ?></th>
									<th scope="col"><?php echo app('translator')->getFromJson('messages.todate'); ?></th>
									<th scope="col"><?php echo app('translator')->getFromJson('messages.assignedadmin'); ?></th>
									<th scope="col"><?php echo app('translator')->getFromJson('messages.status'); ?></th>
									<th scope="col"><?php echo app('translator')->getFromJson('messages.description'); ?></th>																			
                                  </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<tr>
											<td> <?php echo e($ticket->ticket_no); ?> </td>
											<td> <?php echo e($ticket->user->name); ?> </td>
											<td> <?php echo e($ticket->start_date); ?> </td>
											<td> <?php echo e($ticket->end_date); ?> </td>
											<td> 
												<?php if(isset($ticket->assigned_admin->name)): ?>
													<?php echo e($ticket->assigned_admin->name); ?>

												<?php endif; ?>
											</td>
											<td>
												<?php if($ticket->status == 0): ?>
													<span class="badge"><?php echo app('translator')->getFromJson('messages.Closed'); ?></span>
												<?php elseif($ticket->status == 1): ?>
													<span class="badge" style="background:green;"><?php echo app('translator')->getFromJson('messages.Opened'); ?></span>	
												<?php elseif($ticket->status == 2): ?>
													<span class="badge" style="background:orange;"><?php echo app('translator')->getFromJson('messages.Reopened'); ?></span>														
												<?php endif; ?>
											</td>
											<td> <?php echo e($ticket->description); ?> </td>											
										</tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </tbody>
                        </table>
					<?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


											
	

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\task\resources\views/tickets/assignedtickets.blade.php ENDPATH**/ ?>