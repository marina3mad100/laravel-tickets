<?php $__env->startSection('content'); ?>






<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo app('translator')->getFromJson('messages.SiteFunction'); ?></div>

                <div class="card-body">
 
					<?php echo $__env->make('partials._messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
                    <?php if($controller_function->count()>0): ?>                                   
                        <table id="example" class="table table-striped">
							<thead>
							  <tr>
								 <th scope="col"><?php echo app('translator')->getFromJson('messages.FunctionName'); ?></th>
								 <th scope="col"><?php echo app('translator')->getFromJson('messages.Permissions'); ?></th>
								
							  </tr>
							</thead>
							<tbody>
								<?php $__currentLoopData = $controller_function; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $function): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							
										<tr>
											<td><?php echo e($function->name); ?> </td>
											<td>
												<form action="<?php echo e(route('functions.add_delete' , [app()->getLocale() , $function->id ])); ?>" method="POST"  >
													<?php echo e(csrf_field()); ?>

										
													<div class="form-check">
														<?php if($permissions->count()>0): ?>
															<?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>								
															<input class="form-check-input" type="checkbox" id="role<?php echo e($permission->id); ?>" name="permission[]" value="<?php echo e($permission->id); ?>"
																<?php if(!empty($function->permissions)): ?>
																	<?php $__currentLoopData = $function->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fun_perm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>{
																		<?php if($fun_perm->id == $permission->id): ?>
																			checked
																		<?php endif; ?>	
																
																	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																		
																
																<?php endif; ?>
															>
															<label class="form-check-label"  >
																	<?php echo e($permission->name); ?>

																  </label><br>
															<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														<?php endif; ?>
														
													</div>
													<button type="submit" class="btn btn-danger"><?php echo app('translator')->getFromJson('messages.save'); ?></button>
		
												</form>
											</td>
															
											

							
										</tr>
									
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>								
							</tbody>
						</table> 
											
					<?php endif; ?>	
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\task\resources\views/functions/index.blade.php ENDPATH**/ ?>