<?php $__env->startSection('content'); ?>






<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo app('translator')->getFromJson('messages.TicketCreate'); ?></div>

                <div class="card-body">

					<?php echo $__env->make('partials._messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    

                    <form action="<?php echo e(route('tickets.store' , app()->getLocale())); ?>" method="POST"  >
                        <?php echo e(csrf_field()); ?>

						<div class="form-group">
							<label for="name"><?php echo app('translator')->getFromJson('messages.owner'); ?></label>
							<select class="form-control" name="user_id">
								<?php if(!empty($users)): ?>
									<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($user->id); ?>" <?php if($errors->any()&& old('user_id') == $user->id ): ?> <?php echo e('selected'); ?> <?php elseif(Session::has('success')): ?> <?php echo e(''); ?>  <?php endif; ?>><?php echo e($user->name); ?></option>									
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
								
							</select>
                        </div>						
                        <div class="form-group">
							<label for="name"><?php echo app('translator')->getFromJson('messages.TicketNo'); ?></label>
							<input type="text" class="form-control" name="ticket_no" value="<?php if($errors->any()): ?> <?php echo e(old('ticket_no')); ?> <?php elseif(Session::has('success')): ?> <?php echo e(''); ?>  <?php endif; ?>" placeholder="<?php echo app('translator')->getFromJson('messages.Enter'); ?> <?php echo app('translator')->getFromJson('messages.TicketNo'); ?>">
                        </div>
 
                        <div class="form-group">
							<label for="name"><?php echo app('translator')->getFromJson('messages.fromdate'); ?> (<?php echo app('translator')->getFromJson('messages.currentdate'); ?>)</label>
							<input type="text" class="form-control" name="start_date" value="<?php if($errors->any()): ?> <?php echo e(old('start_date')); ?> <?php else: ?> <?php echo e(date('Y-m-d')); ?>  <?php endif; ?>" placeholder="<?php echo app('translator')->getFromJson('messages.Enter'); ?> <?php echo app('translator')->getFromJson('messages.fromdate'); ?>"readonly >
                        </div>
                        <div class="form-group">
							<label for="name"><?php echo app('translator')->getFromJson('messages.todate'); ?></label>
							<input type="text" class="form-control date" name="end_date" value="<?php if($errors->any()): ?> <?php echo e(old('end_date')); ?> <?php else: ?> <?php echo e(date('Y-m-d')); ?>  <?php endif; ?>" placeholder="<?php echo app('translator')->getFromJson('messages.Enter'); ?> <?php echo app('translator')->getFromJson('messages.todate'); ?>" readonly >
                        </div>						
                       <div class="form-group">
							<label for="name"><?php echo app('translator')->getFromJson('messages.description'); ?></label>
							<textarea name="description" class="form-control"><?php if($errors->any()): ?> <?php echo e(old('description')); ?> <?php elseif(Session::has('success')): ?> <?php echo e(''); ?>  <?php endif; ?></textarea>
                        </div>						
	                    <div class="form-group" >
							<label for="name"><?php echo app('translator')->getFromJson('messages.assignedadmin'); ?></label>
							<select class="form-control" name="user_assigned_id">
								<option value=""><?php echo app('translator')->getFromJson('messages.select'); ?> <?php echo app('translator')->getFromJson('messages.Admins'); ?></option>
								<?php if(!empty($admins)): ?>
									<?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($user->id); ?>" <?php if($errors->any() && old('user_assigned_id') == $user->id ): ?> <?php echo e('selected'); ?> <?php elseif(Session::has('success')): ?> <?php echo e(''); ?>  <?php endif; ?> ><?php echo e($user->name); ?></option>									
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
								
							</select>
                        </div>
    
                        <button type="submit" class="btn btn-primary"><?php echo app('translator')->getFromJson('messages.save'); ?></button>
                      </form>      
                    







                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\task\resources\views/tickets/create.blade.php ENDPATH**/ ?>