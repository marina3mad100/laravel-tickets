<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Create Ticket</div>

                <div class="card-body">

					<?php echo $__env->make('partials._messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <form action="<?php echo e(route('tickets.save')); ?>" method="POST"  >
                        <?php echo e(csrf_field()); ?>

						<div class="form-group">
							<label for="name">Owner</label>
							<select class="form-control" name="user_id" <?php if(Auth::user()->is_owner() ): ?> <?php echo e('readonly'); ?> <?php endif; ?> >
								<?php if(!empty($users)): ?>
									<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($user->id); ?>" <?php if(Auth::user()->is_owner() && Auth::user()->id == $user->id ): ?> <?php echo e('selected'); ?> <?php elseif($errors->any()&& old('user_id') == $user->id ): ?> <?php echo e('selected'); ?> <?php elseif(Session::has('success')): ?> <?php echo e(''); ?>  <?php endif; ?>><?php echo e($user->name); ?></option>									
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
								
							</select>
                        </div>						
                        <div class="form-group">
							<label for="name">Ticket No</label>
							<input type="text" class="form-control" name="ticket_no" value="<?php if($errors->any()): ?> <?php echo e(old('ticket_no')); ?> <?php elseif(Session::has('success')): ?> <?php echo e(''); ?>  <?php endif; ?>" placeholder="Enter Ticket No">
                        </div>
 
                        <div class="form-group">
							<label for="name">From Date (current date)</label>
							<input type="text" class="form-control" name="start_date" value="<?php if($errors->any()): ?> <?php echo e(old('start_date')); ?> <?php else: ?> <?php echo e(date('Y-m-d')); ?>  <?php endif; ?>" placeholder="Enter From Date"readonly >
                        </div>
                        <div class="form-group">
							<label for="name">To Date</label>
							<input type="text" class="form-control date" name="end_date" value="<?php if($errors->any()): ?> <?php echo e(old('end_date')); ?> <?php else: ?> <?php echo e(date('Y-m-d')); ?>  <?php endif; ?>" placeholder="Enter To Date" readonly >
                        </div>						
                       <div class="form-group">
							<label for="name">Desription</label>
							<textarea name="description" class="form-control"><?php if($errors->any()): ?> <?php echo e(old('description')); ?> <?php elseif(Session::has('success')): ?> <?php echo e(''); ?>  <?php endif; ?></textarea>
                        </div>						
	                    <div class="form-group" style=" <?php if(Auth::user()->is_owner()): ?>  <?php echo e('display:none'); ?>  <?php endif; ?> ">
							<label for="name">Assigned To</label>
							<select class="form-control" name="user_assigned_id">
								<option value="">Select Admin</option>
								<?php if(!empty($admins)): ?>
									<?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($user->id); ?>" <?php if($errors->any() && old('user_assigned_id') == $user->id ): ?> <?php echo e('selected'); ?> <?php elseif(Session::has('success')): ?> <?php echo e(''); ?>  <?php endif; ?> ><?php echo e($user->name); ?></option>									
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
								
							</select>
                        </div>
    
                        <button type="submit" class="btn btn-primary">Save</button>
                      </form>      
                    







                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\task\resources\views/tickets/addticket.blade.php ENDPATH**/ ?>